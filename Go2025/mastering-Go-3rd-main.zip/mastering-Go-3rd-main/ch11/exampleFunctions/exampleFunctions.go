package exampleFunctions

func LengthRange(s string) int {
	i := 0
	for _, _ = range s {
		i = i + 1
	}
	return i
}
