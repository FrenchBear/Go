package cleanup

import "fmt"

func Foo() {
	fmt.Println("Inside foo!")
}
