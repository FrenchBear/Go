## What if a textfile ends without a newline?

As this is not mentioned in the *Mastering Go, 3rd edition* book, I have included separate version of `byWord.go`, `byLine.go` and `byCharacter.go` named `byWord_noNewLine.go`, `byLine_noNewLine.go` and `byCharacter_noNewLine.go`, respectively that show how to handle plain text files that do not end with a newline character.

Enjoy!

